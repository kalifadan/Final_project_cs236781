# Data

This directory should include all raw datasets which will be used. This is for convenience when
testing the result notebooks. For example, when using the [MIT-BIH Atrial Fibrillation Database](https://physionet.org/content/afdb/1.0.0/) dataset, place a directory `afdb` with all [`.atr`,`.hea`] files.
